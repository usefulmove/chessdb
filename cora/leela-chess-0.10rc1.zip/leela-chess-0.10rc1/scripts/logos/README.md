
### Black and white logo

Raster:

![logo-black-and-white](logo-black-and-white.png)

Vector:

![logo-black-and-white](logo-black-and-white.svg)

### Black background

Raster:

![logo-black-background-cropped](logo-black-background.png)

Vector:

![logo-black-background-cropped](logo-black-background.svg)

### Transparent background

Raster:

![logo-transparent-background-cropped](logo-transparent-background.png)

Vector:

![logo-transparent-background-cropped](logo-transparent-background.svg)
